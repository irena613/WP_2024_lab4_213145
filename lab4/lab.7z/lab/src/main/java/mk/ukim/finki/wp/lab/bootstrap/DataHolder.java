package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Artist> artists = new ArrayList<>();
    public static List<Song> songs = new ArrayList<>();

    @PostConstruct
    public void init(){

        artists.add(new Artist("Namjoon", "Kim", "returning in 219 days"));
        artists.add(new Artist("Seokjin", "Kim", "ALREADY BACK!!"));
        artists.add(new Artist("Yoongi", "Min", "returning in 230 days"));
        artists.add(new Artist("Hoseok", "Jung", "ALREADY BACK!!"));
        artists.add(new Artist("Jimin", "Park", "returning in 220 days"));
        artists.add(new Artist("Taehyung", "Kim", "returning in 219 days"));
        artists.add(new Artist("Jungkook", "Jeon", "returning in 220 days"));

        List<Artist> performer1 = new ArrayList<>();
        performer1.add(artists.get(0));

        List<Artist> performer2 = new ArrayList<>();
        performer2.add(artists.get(1));

        List<Artist> performer3 = new ArrayList<>();
        performer3.add(artists.get(2));

        List<Artist> performer4 = new ArrayList<>();
        performer4.add(artists.get(3));

        List<Artist> performer5 = new ArrayList<>();
        performer5.add(artists.get(4));

        List<Artist> performer6 = new ArrayList<>();
        performer6.add(artists.get(5));

        List<Artist> performer7 = new ArrayList<>();
        performer6.add(artists.get(6));

        songs.add(new Song("19940912", "LOST", "HipHop", 2024, performer1));
        songs.add(new Song("19912204", "I'll be there", "Pop", 2024, performer2));
        songs.add(new Song("19930309", "Haegeum", "Rap", 2023, performer3));
        songs.add(new Song("19940218", "Neuron", "HipHop", 2024, performer4));
        songs.add(new Song("19951013", "Who", "Pop", 2024, performer5));
        songs.add(new Song("19951230", "Rainy Days", "R&B", 2023, performer6));
        songs.add(new Song("19970901", "Standing next to you", "Pop", 2023, performer7));
    }

}
